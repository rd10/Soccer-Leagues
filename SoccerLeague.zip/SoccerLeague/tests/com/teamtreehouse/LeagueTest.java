package com.teamtreehouse;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import static org.junit.Assert.*;

public class LeagueTest {
    private League league;

    /*@Before
    public void setUp() throws Exception {
        List<Team> teams = new ArrayList<>();
        teams.add(new Team("Leon"));
        teams.add(new Team("Leon"));
        league = new League(teams);
    }*/

    /*@Test
    public void creatingSchedulePopulatesMatches() {
        league.beginLeague();
        Match[] matches = league.getMatches();
        assertEquals("America", matches[0].getHomeTeam());
    }   */
}