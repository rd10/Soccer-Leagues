package com.teamtreehouse;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class ScheduleTest {

    private Schedule schedule;

    /*@Before
    public void setUp() throws Exception {
        List<Team> teams = new ArrayList<>();
        teams.add(new Team("Leon"));
        teams.add(new Team("America"));

        schedule = new Schedule(teams, 2);
    }

    @Test
    public void initializingSchedulePreparesMatches() {
        List<Match> matches = schedule.getMatches();
        assertEquals("Leon", matches.get(0).getHomeTeam().getName());
        assertEquals("America", matches.get(0).getAwayTeam().getName());

        assertEquals("America", matches.get(1).getHomeTeam().getName());
        assertEquals("Leon", matches.get(1).getAwayTeam().getName());

    }*/
}